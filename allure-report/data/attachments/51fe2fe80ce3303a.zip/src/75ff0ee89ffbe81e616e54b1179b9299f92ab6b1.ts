import {test, expect, Locator} from "@playwright/test"

test('test1', async ({page}) => {
    await page.goto('https://demowebshop.tricentis.com/');      
    
}); 

test.fail('test2', async ({page}) => {
    await page.goto('https://demowebshop.tricentis.com/');      
    
});

test('test3', async ({page}) => {
    await page.goto('https://demowebshop.tricentis.com/');      
    
});